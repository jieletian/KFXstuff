ABETE01 v 0.5

By Dragonlich


This tree was intended to be used to create a woodland/forest area for a level with Druids as the protagonists.
It's not the best color, but you get the idea.


Hope you like it. If you have any suggestions, please contact me.

To be able to add this object to your maps you must insert the following lines into objects.cfg
After that put this "abete01.zip" file in the folder that contains objects "keeper/fxdata" or "keeper/campgns/yourcampain_cfg/"

Put in the object.cfg the 

----------------------------
[objectxxx]
Name = ABETE01_TREE
Genre = DECORATION
AnimationID = ABETE_SPRITES
AnimationSpeed = 250
Size_XY = 0
Size_YZ = 0
MaximumSize = 200
DestroyOnLava = 0
DestroyOnLiquid = 0
Health = 200
FallAcceleration = 0
LightUnaffected = 0
LightIntensity = 50
LightRadius = 6
LightIsDynamic = 1
Properties = CHOWNED_ON_ROOM_CLAIM DESTROYED_ON_ROOM_PLACE


NB: It have only 1 set of animation (No TOP vision or 1st person vision) but it look ok to me.
