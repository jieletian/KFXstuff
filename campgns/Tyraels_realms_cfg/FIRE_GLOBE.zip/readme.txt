[object164]
Name = FIRE_PLACE
Genre = DECORATION
AnimationID = FIRE_PLACE
AnimationSpeed = 250
Size_XY = 0
Size_YZ = 0
MaximumSize = 200
DestroyOnLava = 0
DestroyOnLiquid = 0
Health = 200
FallAcceleration = 0
LightUnaffected = 0
LightIntensity = 50
LightRadius = 3
LightIsDynamic = 1
Properties = CHOWNED_ON_ROOM_CLAIM DESTROYED_ON_ROOM_PLACE

By Dragonlich with help of Ben