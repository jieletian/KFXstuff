
FIRE_GLOBE by Dragonlich


This item is designed to create a zone of power in the dungeon. Someone also used it as the heart of the Dungeon:
Use it however you want, but I advise you NOT to decrease the number of frames and not to do it too fast or too slow.

To be able to add this object to your maps you must insert the following lines into objects.cfg
After that put this "fuoco.zip" file in the folder that contains objects.

Put in the object.cfg the 

----------------------------
[objectxxx]
Name = FIRE_GLOBE
Genre = DECORATION
AnimationID = FIRE_PLACE
AnimationSpeed = 250
Size_XY = 0
Size_YZ = 0
MaximumSize = 200
DestroyOnLava = 0
DestroyOnLiquid = 0
Health = 200
FallAcceleration = 0
LightUnaffected = 0
LightIntensity = 50
LightRadius = 3
LightIsDynamic = 1
Properties = CHOWNED_ON_ROOM_CLAIM DESTROYED_ON_ROOM_PLACE
----------------------------

Replace xxx with the correct number sequence