
DUNGEON KEEPER FX Sauron Eye ver 1.0 !

You have to add an new object in "object.cfg" with the right number not 999.
Copy this OCCHIO.ZIP file in your capain or Keeper/Fxdata/ folder.

[object999]
Name = OCCHIO
Genre = FURNITURE
AnimationID = OCCHIO
AnimationSpeed = 100
Size_XY = 100
Size_YZ = 100
MaximumSize = 230
DestroyOnLava = 0
DestroyOnLiquid = 0
Health = 30000
FallAcceleration = 0
LightUnaffected = 0
LightIntensity = 50
LightRadius = 30
LightIsDynamic = 1
Properties = DESTROYED_ON_ROOM_PLACE HEART
UpdateFunction = UPDATE_DUNGEON_HEART


By Dragonlich
Contact: dragonlich@rovaro.it