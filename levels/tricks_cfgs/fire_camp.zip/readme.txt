FIRE CAMP v 1.0

By Dragonlich


This campfire is designed to be used in an area that the heroes use as a base camp and are supposed to defend.
It should be paired with a terrain type that has the characteristics of "Guard Post" but is identical in appearance to "unclaimed terrain".
However, it is possible to place it in the center of an area with barracks or a guard post. It gives off light and gives a nice effect in a game.

X=GUARD POST
F = Fire_camp
XXX
XFX
XXX

Hope you like it. If you have any suggestions, please contact me.

To be able to add this object to your maps you must insert the following lines into objects.cfg
After that put this "fire_camp.zip" file in the folder that contains objects "keeper/fxdata" or "keeper/campgns/yourcampain_cfg/"

Put in the object.cfg the 

----------------------------
[objectxxx]
Name = FIRE_GLOBE
Genre = DECORATION
AnimationID = FIRE_GLOBE
AnimationSpeed = 255
Size_XY = 100
Size_YZ = 100
MaximumSize = 200
DestroyOnLava = 0
DestroyOnLiquid = 0
Health = 200
FallAcceleration = 0
LightUnaffected = 0
LightIntensity = 50
LightRadius = 5
LightIsDynamic = 1
Properties = CHOWNED_ON_ROOM_CLAIM DESTROYED_ON_ROOM_PLACE

Replace xxx with the correct number sequence
